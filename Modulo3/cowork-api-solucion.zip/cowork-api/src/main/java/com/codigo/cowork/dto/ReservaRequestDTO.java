package com.codigo.cowork.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO de entrada para crear una Reserva.
 *
 * Se aplican anotaciones @JsonFormat tambien en el request para que Jackson
 * acepte la fecha en formato "yyyy-MM-dd" y las horas en "HH:mm" durante la
 * deserializacion del JSON entrante.
 *
 * Observe que NO incluye los campos 'estado' ni 'passwordInterno':
 *  - 'estado' lo define el Service (siempre PENDIENTE al crear, regla R6.1).
 *  - 'passwordInterno' es un campo interno y no debe ser controlado por el cliente.
 */
public record ReservaRequestDTO(
        Long salaId,
        String responsable,
        String email,

        @JsonFormat(pattern = "yyyy-MM-dd")
        LocalDate fecha,

        @JsonFormat(pattern = "HH:mm")
        LocalTime horaInicio,

        @JsonFormat(pattern = "HH:mm")
        LocalTime horaFin
) { }
