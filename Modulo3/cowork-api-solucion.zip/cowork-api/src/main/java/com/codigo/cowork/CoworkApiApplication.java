package com.codigo.cowork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la API de CoworkLima S.A.C.
 *
 * @SpringBootApplication combina:
 *   - @SpringBootConfiguration  -> declara esta clase como fuente de configuracion
 *   - @EnableAutoConfiguration  -> activa la auto-configuracion (DispatcherServlet,
 *                                  Jackson, Tomcat embebido) al detectar starter-web
 *   - @ComponentScan            -> escanea com.codigo.cowork y subpaquetes
 *                                  registrando @RestController, @Service y @Repository
 */
@SpringBootApplication
public class CoworkApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoworkApiApplication.class, args);
    }
}
