package com.codigo.cowork.mapper;

import com.codigo.cowork.dto.SalaRequestDTO;
import com.codigo.cowork.dto.SalaResponseDTO;
import com.codigo.cowork.model.Sala;

/**
 * Mapper Sala <-> DTO (Tema 2.2).
 * Todos los metodos son estaticos y puros: dado el mismo input, devuelven
 * el mismo output sin efectos secundarios.
 *
 * El campo derivado 'descripcionCorta' (Tema 2.5, regla R5) se construye aqui:
 *   "<codigo> - <nombre> (cap. <capacidad>)"
 */
public final class SalaMapper {

    private SalaMapper() { } // clase utilitaria, no instanciable

    public static Sala toEntity(SalaRequestDTO dto) {
        Sala sala = new Sala();
        sala.setCodigo(dto.codigo());
        sala.setNombre(dto.nombre());
        sala.setCapacidad(dto.capacidad());
        sala.setUbicacion(dto.ubicacion());
        // Regla R6.2: si 'activa' viene null se asume true
        sala.setActiva(dto.activa() == null || dto.activa());
        return sala;
    }

    public static SalaResponseDTO toResponse(Sala s) {
        String descripcionCorta = String.format(
                "%s - %s (cap. %d)",
                s.getCodigo(), s.getNombre(), s.getCapacidad()
        );
        return new SalaResponseDTO(
                s.getId(),
                s.getCodigo(),
                s.getNombre(),
                s.getCapacidad(),
                s.getUbicacion(),
                s.isActiva(),
                descripcionCorta
        );
    }

    /** Aplica los cambios del DTO sobre una entidad existente. */
    public static void aplicarCambios(Sala destino, SalaRequestDTO dto) {
        destino.setCodigo(dto.codigo());
        destino.setNombre(dto.nombre());
        destino.setCapacidad(dto.capacidad());
        destino.setUbicacion(dto.ubicacion());
        if (dto.activa() != null) {
            destino.setActiva(dto.activa());
        }
    }
}
