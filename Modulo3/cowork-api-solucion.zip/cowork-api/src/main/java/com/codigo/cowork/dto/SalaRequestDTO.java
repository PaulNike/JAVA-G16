package com.codigo.cowork.dto;

/**
 * DTO de entrada para crear o actualizar una Sala.
 * Implementado como record (Tema 2.5): inmutable, conciso y compatible con
 * la deserializacion automatica de Jackson.
 *
 * El campo 'activa' es Boolean (wrapper) y no boolean primitivo, para poder
 * distinguir si el cliente lo envio o no. Si llega null, el Service aplicara
 * el default true (regla R6.2).
 */
public record SalaRequestDTO(
        String codigo,
        String nombre,
        Integer capacidad,
        String ubicacion,
        Boolean activa
) { }
