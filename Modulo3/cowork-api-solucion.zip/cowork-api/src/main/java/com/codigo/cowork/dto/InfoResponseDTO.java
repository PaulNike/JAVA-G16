package com.codigo.cowork.dto;

/**
 * DTO de respuesta para el endpoint informativo GET /api/info.
 */
public record InfoResponseDTO(
        String nombre,
        String version,
        String autor
) { }
