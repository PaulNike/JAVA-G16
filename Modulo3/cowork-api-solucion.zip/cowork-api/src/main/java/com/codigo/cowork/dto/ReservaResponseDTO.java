package com.codigo.cowork.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO de salida para Reserva.
 *
 * Aplicacion del Tema 2.5:
 *   - @JsonFormat con patron "yyyy-MM-dd" para la fecha.
 *   - @JsonFormat con patron "HH:mm" para las horas (sin segundos).
 *   - NO se incluye el campo passwordInterno: queda excluido por diseno del
 *     contrato, sin necesidad de @JsonIgnore en el modelo.
 */
public record ReservaResponseDTO(
        Long id,
        Long salaId,
        String responsable,
        String email,

        @JsonFormat(pattern = "yyyy-MM-dd")
        LocalDate fecha,

        @JsonFormat(pattern = "HH:mm")
        LocalTime horaInicio,

        @JsonFormat(pattern = "HH:mm")
        LocalTime horaFin,

        String estado
) { }
