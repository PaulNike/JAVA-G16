package com.codigo.cowork.dto;

/**
 * DTO de salida para Sala.
 * Incluye el campo derivado 'descripcionCorta' que es calculado por el Mapper
 * (NO existe en el modelo). Formato: "<codigo> - <nombre> (cap. <capacidad>)".
 *
 * Cumple R5: record para serializacion limpia con Jackson.
 */
public record SalaResponseDTO(
        Long id,
        String codigo,
        String nombre,
        Integer capacidad,
        String ubicacion,
        boolean activa,
        String descripcionCorta
) { }
