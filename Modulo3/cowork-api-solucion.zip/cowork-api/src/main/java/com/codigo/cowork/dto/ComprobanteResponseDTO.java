package com.codigo.cowork.dto;

/**
 * DTO de respuesta para el endpoint de subida de comprobante (multipart).
 * Devuelve el nombre del archivo, su tamano en bytes y los datos del cliente
 * y la reserva asociados.
 */
public record ComprobanteResponseDTO(
        Long reservaId,
        String clienteId,
        String nombreArchivo,
        long tamanoBytes,
        String mensaje
) { }
