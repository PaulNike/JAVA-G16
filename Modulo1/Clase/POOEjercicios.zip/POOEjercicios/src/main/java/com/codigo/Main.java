package com.codigo;

import com.codigo.abstractas.Vehiculo;
import com.codigo.modelos.Auto;
import com.codigo.modelos.Moto;

public class Main {
    public static void main(String[] args) {

        Vehiculo vehiculo1 = new Auto("Toyota", "Corolla", 4);
        Vehiculo vehiculo2 = new Moto("Yamaha", "FZ", true);

        vehiculo1.encender();
        vehiculo1.acelerar(30);
        vehiculo1.mostrarInformacion();
        vehiculo1.frenar(30);
        vehiculo1.apagar();

        System.out.println();
        vehiculo2.encender();
        vehiculo2.acelerar(30);
        vehiculo2.mostrarInformacion();
        vehiculo2.frenar(30);
        vehiculo2.apagar();

    }
}
